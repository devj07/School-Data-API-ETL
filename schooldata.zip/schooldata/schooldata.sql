use students;
select * from students;
select * from students
order by gpa DESC;

Select Count(id) from students;