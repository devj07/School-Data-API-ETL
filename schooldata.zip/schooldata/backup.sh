#!/bin/bash

# Database credentials
USER="root"
PASSWORD="admin"
HOST="127.0.0.1"
DB_NAME="students"

# Backup directory
BACKUP_DIR="/d/Downloads/schooldata"

# Date format for backup file name
DATE=$(date +%Y%m%d_%H%M%S)

# Backup file name
BACKUP_FILE="$BACKUP_DIR/${DB_NAME}_backup_${DATE}.sql"

# Create backup
mysqldump -u $USER -p$PASSWORD -h $HOST $DB_NAME > $BACKUP_FILE

# Print message
echo "Backup created: $BACKUP_FILE"
